<?php
 error_reporting(0);
 include 'nav.php';
 include 'admin_session.php';
 $seri_id=$_GET['updateabout'];

 if (isset($_POST['updatabout']))
 {
   
   $title=$_POST['title'];
   $description=$_POST['description'];
   $sql=mysqli_query($link,"UPDATE about SET title='$title', description='$description' WHERE id=$seri_id;");
   if ($sql) 
   {  
        $successmessage .='update about Successefully';	
   } 
   else 
   {
    $errormessage .='upload photo failed! failed';  
   }
   
}

?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Bootstrap tab card start -->
                                                <div class="card">
                                      <div class="card-block">
                                                        <!-- Row start -->
                                                        <div class="row">
                                                            <div class="col-lg-12 col-xl-12">
                                                                <div class="sub-title">About us</div>
                                                                <!-- Nav tabs -->
                                                                <ul class="nav nav-tabs  tabs" role="tablist">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#home1" role="tab">Add new</a>
                                                                    </li>
                                                                </ul>
                                                                <!-- Tab panes -->
                                                                <div class="tab-content tabs card-block">
                                                                    <div class="tab-pane active" id="home1" role="tabpanel">
                                                                          
                                            <?php
                                                if ( isset($successmessage)) {
                                                    echo '
                                                        <div class="card borderless-card">
                                                            <div class="card-block success-breadcrumb">
                                                                <div class="breadcrumb-header">
                                                                    <span>'.$successmessage.'</span>
                                                                    <br>
                                                                    <a class="btn btn-success" href="about.php" role="tab">To About page</a>
                                                                  
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ';
                                                }
                                                ?>
                                                <?php
                                                if ( isset($errormessage)) {
                                                  echo '
                                                      <div class="card borderless-card">
                                                          <div class="card-block danger-breadcrumb">
                                                              <div class="breadcrumb-header">
                                                                  <span>'.$errormessage.'</span>
                                                              </div>
                                                          </div>
                                                      </div>
                                                  ';
                                                }
                                                ?>
                                            <div class="card-block">
                                            <?php
                                                if (isset($_GET['updateabout'])) {
                                                    $ser_id=$_GET['updateabout'];
                                                    $quer=mysqli_query($link,"SELECT * FROM about WHERE about.id=$ser_id");
                                                    while ($row=mysqli_fetch_array($quer)){
                      
                                                        ?>
                                                    <form action="" method="POST" enctype="multipart/form-data">
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">About title</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="title" value="<?php echo $row['title']; ?>" class="form-control form-control-normal"
                                                           >
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Description</label>
                                                        <div class="col-sm-10">                                                                
                                                        <textarea name="description" id="editor1" rows="10" cols="80">
                                                        <?php echo $row['description']; ?>
                                                            </textarea>
                                                        </div>
                                                    
                                                    <div class="form-group row">
                                                        <div class="col-sm-12">
                                                            <input type="submit" name="updatabout" value="Update About"
                                                            class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                                        <?php
                                                    } 
                                                }
                                                ?>
                                            </div>
                                                                   
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                         </div>
                             </div>
                            </div>
                           </div>
                          </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
<?php 
include 'footer.php';
?>