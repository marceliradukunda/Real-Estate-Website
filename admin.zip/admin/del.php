<?php

include '../config/connection.php';

if (isset($_GET['delmessage'])) {
$id=$_GET['delmessage'];
$del=$link->query("DELETE FROM message WHERE id={$id}") or die("Delete Failed");


 if ($del) {
        
        echo "<script type='text/javascript'>alert('Deleted! Successfully!')</script>";   
        header("location:message.php");
    }
    else {
        
		?>
        <script type="text/javascript">alert('Delete failed!')</script>
        <?php
        header("location:message.php");
    }
}
?>