<?php
 include 'nav.php';
error_reporting(0);
 if (isset($_POST['addhome'])){

    $target="../img/".basename($_FILES['image']['name']);

    $image=$_FILES['image']['name'];
    
    $alt=$_POST['alt'];
    
    if (move_uploaded_file($_FILES['image']['tmp_name'],$target)){
       
        $sql=mysqli_query($link,"INSERT INTO slide(alt,image) VALUES ('$alt','$image')");
        
        if ($sql) {
            $successmessage .='Add Slide content Successefully';	
        }
        else {
            $errormessage .='Add Slide content failed!'.$link->error;	    
        }    
    }
    else{
        $errormessage .='Add Slide content failed! Try Again';
    }
}


?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Bootstrap tab card start -->
                                                <div class="card">
                                      <div class="card-block">
                                                        <!-- Row start -->
                                                        <div class="row">
                                                            <div class="col-lg-12 col-xl-12">
                                                                <div class="sub-title">Home content</div>
                                                                <!-- Nav tabs -->
                                                                <ul class="nav nav-tabs  tabs" role="tablist">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#home1" role="tab">Add new</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#profile1" role="tab">All content</a>
                                                                    </li>
                                                                </ul>
                                                                <!-- Tab panes -->
                                                                <div class="tab-content tabs card-block">
                                                                    <div class="tab-pane active" id="home1" role="tabpanel">
                                                                          
                                            <?php
                                                if ( isset($successmessage)) {
                                                    echo '
                                                        <div class="card borderless-card">
                                                            <div class="card-block success-breadcrumb">
                                                                <div class="breadcrumb-header">
                                                                    <span>'.$successmessage.'</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ';
                                                }
                                                ?>
                                                <?php
                                                if ( isset($errormessage)) {
                                                  echo '
                                                      <div class="card borderless-card">
                                                          <div class="card-block danger-breadcrumb">
                                                              <div class="breadcrumb-header">
                                                                  <span>'.$errormessage.'</span>
                                                              </div>
                                                          </div>
                                                      </div>
                                                  ';
                                                }
                                                ?>
                                            <div class="card-block">
                                                <form action="" method="POST" enctype="multipart/form-data">
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Alt</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="alt" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Photo</label>
                                                        <div class="col-sm-10">
                                                            <input type="file" name="image"
                                                            class="form-control form-control-capitalize">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="form-group row">
                                                        <div class="col-sm-12">
                                                            <input type="submit" name="addhome" value="Add home content"
                                                            class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                            </div>
                                                                   
                                            </div>
                                            <div class="tab-pane" id="profile1" role="tabpanel">
                                                <div class=" table-border-style">
                                                    <div class="table-responsive">
                                                        <table id="zero_config" class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Photo</th>
                                                                    <th>Alt</th>
                                                                    <th>Delete</th>
                                                                    <th>Update</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php
                                                                $quer=mysqli_query($link,"SELECT * FROM slide");
                                                                while ($row=mysqli_fetch_array($quer)){
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $row['id'] ; ?></td>
                                                                    <td><?php echo "<img style='width: 100px;' src='../img/".$row['image']."'> "; ?></td>
                                                                    <td><?php echo $row['alt'] ; ?></td>
                                                                    <td><a class="btn btn-danger"  href="delete.php?delhome=<?php echo $row['id']; ?> " onclick="return confirm('are you sure! you want to delete this home content.')" id="red">Delete</a></td>
                                                                    <td><a class="btn btn-primary"  href="homeupdate.php?updatehome=<?php echo $row['id']; ?>"  id="red">Update</a></td>
                                                                </tr>
                                                                <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                         </div>
                             </div>
                            </div>
                           </div>
                          </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
<?php 

include 'footer.php';
?>