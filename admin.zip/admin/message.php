<?php
 include 'nav.php';
 if (isset($_POST['addcontact'])){
       
   
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $phone=$_POST['phone'];
    $sql=mysqli_query($conn,"INSERT INTO contact VALUES ('','$name','$email','$address','$phone')");
    if ($sql) {
        $successmessage .='Add contact Successefully';	
    }
    else {
        $errormessage .='Add contact failed!';	    
    }    

}


?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Bootstrap tab card start -->
                                                <div class="card">
                                      <div class="card-block">
                                                        <!-- Row start -->
                                                        <div class="row">
                                                            <div class="col-lg-12 col-xl-12">
                                                                <div class="sub-title">Messages</div>
                                                                <!-- Nav tabs -->
                                                                <ul class="nav nav-tabs  tabs" role="tablist">
                                                                   
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#profile" role="tab">All Message</a>
                                                                    </li>
                                                                </ul>
                                                                <!-- Tab panes -->
                                                                <div class="tab-content tabs card-block">
                                                                   
                                            <div class="tab-pane active" id="profile" role="tabpane">
                                                <div class=" table-border-style">
                                                    <div class="table-responsive">
                                                        <table id="zero_config" class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Name</th>
                                                                    <th>Email</th>
                                                                    <!-- <th>Phone</th> -->
                                                                    <th>Messae</th>
                                                                    <!-- <th>Time</th> -->
                                                                    <th>Delete</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php
                                                            $count=1;
                                                                $quer=mysqli_query($link,"SELECT * FROM message");
                                                                while ($row=mysqli_fetch_array($quer))
                                                                {
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $count++ ; ?></td>
                                                                    <td><?php echo $row['name'] ; ?></td>
                                                                    <td><?php echo $row['email'] ; ?></td>
                                                                    <!-- <td><?php echo $row['phone'] ; ?></td> -->
                                                                    <td><?php echo $row['message'] ; ?></td>
                                                                    <!-- <td><?php echo $row['timesent'] ; ?></td> -->
                                                                    <td><a class="btn btn-danger"  href="del.php?delmessage=<?php echo $row['id']; ?> " onclick="return confirm('are you sure! you want to delete this message.')" id="red">Delete</a></td>
                                                                </tr>
                                                                <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                         </div>
                             </div>
                            </div>
                           </div>
                          </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
<?php 

include 'footer.php';
?>