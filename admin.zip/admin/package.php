<?php
 include 'nav.php';
 if (isset($_POST['addpackage'])){
    
    $target1="../photos/".basename($_FILES['image']['name']);
    $image=$_FILES['image']['name'];
    
    $target2="../photos/".basename($_FILES['image1']['name']);
    $image1=$_FILES['image1']['name'];
    
    $target3="../photos/".basename($_FILES['image2']['name']);
    $image2=$_FILES['image2']['name'];
    
    $target4="../photos/".basename($_FILES['image3']['name']);
    $image3=$_FILES['image3']['name'];
    
    $tourtitle=$_POST['tourtitle'];
    $description=$_POST['description'];
    $location   =$_POST['days'];
    $type   =$_POST['location'];
    $days=$_POST['type'];
    $price=$_POST['price'];
    
    move_uploaded_file($_FILES['image']['tmp_name'],$target1);
    move_uploaded_file($_FILES['image1']['tmp_name'],$target2);
    move_uploaded_file($_FILES['image2']['tmp_name'],$target3);
    move_uploaded_file($_FILES['image3']['tmp_name'],$target3);

    $sql=mysqli_query($conn,"INSERT INTO  package VALUES ('','$tourtitle','$description','$days','$location','$type','$image','$image1','$image2','$image3','$price')");
    if ($sql) {
        $successmessage .='Add Package Successefully';	
    }
    else {
        $errormessage .='Add Service failed!';	    
    }   

}


?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Bootstrap tab card start -->
                                                <div class="card">
                                      <div class="card-block">
                                                        <!-- Row start -->
                                                        <div class="row">
                                                            <div class="col-lg-12 col-xl-12">
                                                                <div class="sub-title">Services</div>
                                                                <!-- Nav tabs -->
                                                                <ul class="nav nav-tabs  tabs" role="tablist">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#home1" role="tab">Add new</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#profile1" role="tab">All content</a>
                                                                    </li>
                                                                </ul>
                                                                <!-- Tab panes -->
                                                                <div class="tab-content tabs card-block">
                                                                    <div class="tab-pane active" id="home1" role="tabpanel">
                                                                          
                                            <?php
                                                if ( isset($successmessage)) {
                                                    echo '
                                                        <div class="card borderless-card">
                                                            <div class="card-block success-breadcrumb">
                                                                <div class="breadcrumb-header">
                                                                    <span>'.$successmessage.'</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ';
                                                }
                                                ?>
                                                <?php
                                                if ( isset($errormessage)) {
                                                  echo '
                                                      <div class="card borderless-card">
                                                          <div class="card-block danger-breadcrumb">
                                                              <div class="breadcrumb-header">
                                                                  <span>'.$errormessage.'</span>
                                                              </div>
                                                          </div>
                                                      </div>
                                                  ';
                                                }
                                                ?>
                                            <div class="card-block">
                                            <form action="" method="POST" enctype="multipart/form-data">
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Tour Title</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="tourtitle" class="form-control form-control-normal"
                                                            placeholder="Enter Tour title">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Tour Days</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="days" class="form-control form-control-normal"
                                                            placeholder="Enter Tour Day tour">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Location</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="location" class="form-control form-control-normal"
                                                            placeholder="Enter Location">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Type of package</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="type" class="form-control form-control-normal"
                                                            placeholder="Enter Kind of package">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Tour Price</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="price" class="form-control form-control-normal"
                                                            placeholder="Enter Price">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">About Description</label>
                                                        <div class="col-sm-10">
                                                                                                                                           
                                                        <textarea name="description" id="editor1" rows="10" cols="80">
                                                            </textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Select General Photo</label>
                                                        <div class="col-sm-10">
                                                        <input type="file" name="image" id="file" class="form-control form-control-capitalize" >
                                                         
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">other Photo</label>
                                                        <div class="col-sm-10">
                                                        <input type="file" name="image1" id="file" class="form-control form-control-capitalize" >
                                                         
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">other Photo</label>
                                                        <div class="col-sm-10">
                                                        <input type="file" name="image2" id="file" class="form-control form-control-capitalize" >
                                                         
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">other Photo</label>
                                                        <div class="col-sm-10">
                                                        <input type="file" name="image3" id="file" class="form-control form-control-capitalize" >
                                                         
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="form-group row">
                                                        <div class="col-sm-12">
                                                            <input type="submit" name="addpackage" value="Add Package"
                                                            class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                                                   
                                            </div>
                                            <div class="tab-pane" id="profile1" role="tabpanel">
                                                <div class=" table-border-style">
                                                    <div class="table-responsive">
                                                        <table id="zero_config" class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Title</th>
                                                                    <th>Days</th>
                                                                    <th>Location</th>
                                                                    <th>Type</th>
                                                                    <th>Description</th>
                                                                    <th>price</th>
                                                                    <th colspan="4">Pictures</th>
                                                                    <th>Delete</th>
                                                                    <th>Update</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php
                                                                $quer=mysqli_query($conn,"SELECT * FROM package");
                                                                while ($row=mysqli_fetch_array($quer)){
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $row['pack_id'] ; ?></td>
                                                                    <td><?php echo $row['tour_title'] ; ?></td>
                                                                    <td><?php echo $row['tour_days'] ; ?></td>
                                                                    <td><?php echo $row['location'] ; ?></td>
                                                                    <td><?php echo $row['type'] ; ?></td>
                                                                    <td><?php echo $row['description'] ; ?></td>
                                                                    <td><?php echo $row['price'] ; ?></td>
                                                                    <td><?php echo "<img style='width: 100px;' src='../photos/".$row['photo']."'> "; ?></td>
                                                                    <td><?php echo "<img style='width: 100px;' src='../photos/".$row['photo_one']."'> "; ?></td>
                                                                    <td><?php echo "<img style='width: 100px;' src='../photos/".$row['photo_two']."'> "; ?></td>
                                                                    <td><?php echo "<img style='width: 100px;' src='../photos/".$row['photo_three']."'> "; ?></td> -->
                                                                    <td><a class="btn btn-danger"  href="delete.php?delpackage=<?php echo $row['pack_id']; ?> " onclick="return confirm('are you sure! you want to delete this Package.')" id="red">Delete</a></td>
                                                                    <td><a class="btn btn-primary"  href="packageupdate.php?updatepackage=<?php echo $row['pack_id']; ?>"  id="red">Update</a></td>
                                                                </tr>
                                                                <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                         </div>
                             </div>
                            </div>
                           </div>
                          </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
<?php 

include 'footer.php';
?>