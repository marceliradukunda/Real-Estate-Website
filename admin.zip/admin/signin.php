<?php

include '../config/connection.php';

if (isset($_POST['login'])) {
   $errormessage = "";
    session_start();

	$email=$_POST['email'];
	$password=md5($_POST['password']);
	$email=stripcslashes($email);
	$password=stripcslashes($password);
	$email=mysqli_real_escape_string($link,$email);
	$password=mysqli_real_escape_string($link,$password);
    
	if (empty($email) || empty($password)) {
		header("location:index.php?empty=Email and Password are requied");
	}
	else {
		$select=mysqli_query($link,"SELECT * FROM admin WHERE email='$email' AND password='$password' ") or die(mysqli_error($link)) ;
		
        if (mysqli_num_rows($select)>0) {

	        session_regenerate_id();
	        $verfied=mysqli_fetch_assoc($select); 

	        $_SESSION['adminid']=$verfied['id'] ;
	        $_SESSION['adminusername']=$verfied['username'] ;
	        $_SESSION['adminemail']=$verfied['email'] ;
	        $_SESSION['adminphone']=$verfied['phone'] ;
	        $_SESSION['adminpassword']=$verfied['password'] ;
	        $_SESSION['adminrole']=$verfied['role'] ;
	        session_write_close();
            
            if ($verfied['role']=='admin') {
                $_SESSION['adminid']=$verfied['id'] ;
	        $_SESSION['adminusername']=$verfied['username'] ;
	        $_SESSION['adminemail']=$verfied['email'] ;
	        $_SESSION['adminphone']=$verfied['phone'] ;
	        $_SESSION['adminpassword']=$verfied['password'] ;
	        $_SESSION['adminrole']=$verfied['role'] ;
	        session_write_close();
                header("location:index.php");
            }
            elseif ($verfied['role']=='resident') {
                $_SESSION['adminid']=$verfied['id'] ;
	        $_SESSION['adminusername']=$verfied['username'] ;
	        $_SESSION['adminemail']=$verfied['email'] ;
	        $_SESSION['adminphone']=$verfied['phone'] ;
	        $_SESSION['adminpassword']=$verfied['password'] ;
	        $_SESSION['adminrole']=$verfied['role'] ;
	        session_write_close();
                
                header("location:resident/index.php");
            }
            else {
                $errormessage .='You do not have account';	
            }

		}
		else {
            $errormessage .='You do not have account';			
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Welcome to admin</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Gradient Able Bootstrap admin template made using Bootstrap 4. The starter version of Gradient Able is completely free for personal project." />
    <meta name="keywords" content="free dashboard template, free admin, free bootstrap template, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
    <meta name="author" content="codedthemes">
    <!-- Favicon icon -->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>

<body class="fix-menu">
        <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->

    <section class="login d-flex text-center ">
        <!-- Container-fluid starts -->
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <!-- Authentication card start -->
                    <div class="login-card card-block auth-body mr-auto ml-auto">
                        <form action="" method="post" class="md-float-material">
                            <div class="auth-box">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-left txt-primary">Sign In</h3>
                                    </div>
                                </div>
                                <hr/>
                                
                                <?php
                                      if ( isset($errormessage)) {
                                        echo '
                                            <div class="card borderless-card">
                                                <div class="card-block danger-breadcrumb">
                                                    <div class="breadcrumb-header">
                                                        <span>'.$errormessage.'</span>
                                                    </div>
                                                </div>
                                            </div>
                                        ';
                                      }
                                    ?>
                                <div class="input-group">
                                    <input type="email" class="form-control" name="email" placeholder="Your Email Address" required>
                                    <span class="md-line"></span>
                                </div>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="password" placeholder="Your Password" required>
                                    <span class="md-line"></span>
                                </div>
                                <div class="row m-t-25 text-left">
                                </div>
                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                    <input type="submit" value="Login now." name="login" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                    </div>
                                </div>
                                <hr/>
                                <div class="row">
                                    <div class="col-md-10">
                                        <p class="text-inverse text-left m-b-0">Powered by The Icon Ltd.</p>
                                    </div>
                                </div>

                            </div>
                        </form>
                        <!-- end of form -->
                    </div>
                    <!-- Authentication card end -->
                </div>
                <!-- end of col-sm-12 -->
            </div>
            <!-- end of row -->
        </div>
        <!-- end of container-fluid -->
    </section>
   
    <script type="text/javascript" src="assets/js/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js"></script>
    <script type="text/javascript" src="assets/js/popper.js/popper.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap/js/bootstrap.min.js"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="assets/js/jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="assets/js/modernizr/modernizr.js"></script>
    <script type="text/javascript" src="assets/js/modernizr/css-scrollbars.js"></script>
    <script type="text/javascript" src="assets/js/common-pages.js"></script>
</body>

</html>
