<?php
error_reporting(0);
 include 'nav.php';
 include 'admin_session.php';
 $seri_id=$_GET['updateuser'];

 if (isset($_POST['updatuser'])){
   
    $username=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $role=$_POST['role'];
    $confirmpassword=md5($_POST['confirmpassword']);
    $password=md5($_POST['password']);
    if ($confirmpassword==$password) {
        $sql=mysqli_query($link,"UPDATE admin SET username='$username', email='$email', phone='$phone', role='$role', password='$password' WHERE id=$seri_id;");
        if ($sql) {
            $successmessage .='Update user Successefully';	
        }
        else {
            $errormessage .='Update user failed!';	    
        }
    }
    else {
        $errormessage .='two password not match failed!';	
    }
      
   
}

?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Bootstrap tab card start -->
                                                <div class="card">
                                      <div class="card-block">
                                                        <!-- Row start -->
                                                        <div class="row">
                                                            <div class="col-lg-12 col-xl-12">
                                                                <div class="sub-title">Contact</div>
                                                                <!-- Nav tabs -->
                                                                <ul class="nav nav-tabs  tabs" role="tablist">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#home1" role="tab">Add new</a>
                                                                    </li>
                                                                </ul>
                                                                <!-- Tab panes -->
                                                                <div class="tab-content tabs card-block">
                                                                    <div class="tab-pane active" id="home1" role="tabpanel">
                                                                          
                                            <?php
                                                if ( isset($successmessage)) {
                                                    echo '
                                                        <div class="card borderless-card">
                                                            <div class="card-block success-breadcrumb">
                                                                <div class="breadcrumb-header">
                                                                    <span>'.$successmessage.'</span>
                                                                    <br>
                                                                    <a class="btn btn-primary" href="user.php" role="tab">To User</a>
                                                                  
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ';
                                                }
                                                ?>
                                                <?php
                                                if ( isset($errormessage)) {
                                                  echo '
                                                      <div class="card borderless-card">
                                                          <div class="card-block danger-breadcrumb">
                                                              <div class="breadcrumb-header">
                                                                  <span>'.$errormessage.'</span>
                                                              </div>
                                                          </div>
                                                      </div>
                                                  ';
                                                }
                                                ?>
                                            <div class="card-block">
                                            <?php
                                                if (isset($_GET['updateuser'])) {
                                                    $ser_id=$_GET['updateuser'];
                                                    $quer=mysqli_query($link,"SELECT * FROM admin WHERE admin.id=$ser_id");
                                                    while ($row=mysqli_fetch_array($quer)){
                      
                                                        ?>
                                                    <form action="" method="POST" enctype="multipart/form-data">
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">User Name</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="name" value="<?php echo $row['username']; ?>" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Email</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="email" value="<?php echo $row['email']; ?>" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Phone</label>
                                                        <div class="col-sm-10">
                                                            <input type="text" name="phone" value="<?php echo $row['phone']; ?>" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Role</label>
                                                        <div class="col-sm-10">
                                                            <select name="role"  class="form-control form-control-normal">
                                                            <option><?php echo $row['role']; ?></option>
                                                            <option>admin</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Password</label>
                                                        <div class="col-sm-10">
                                                            <input type="password" name="password" value="<?php echo $row['password']; ?>" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-sm-2 col-form-label">Confirm password</label>
                                                        <div class="col-sm-10">
                                                            <input type="password" name="confirmpassword" value="<?php echo $row['password']; ?>" class="form-control form-control-normal"
                                                            placeholder="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <div class="col-sm-12">
                                                            <input type="submit" name="updatuser" value="Update user"
                                                            class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                                        </div>
                                                    </div>
                                                    
                                                </form>
                                                        <?php
                                                    } 
                                                }
                                                ?>
                                            </div>
                                                                   
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                         </div>
                             </div>
                            </div>
                           </div>
                          </div>
                         </div>
                       </div>
                    </div>
                </div>
            </div>
        </div>
<?php 
include 'footer.php';
?>